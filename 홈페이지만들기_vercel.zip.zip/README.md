
  # 홈페이지 만들기

  This is a code bundle for 홈페이지 만들기. The original project is available at https://www.figma.com/design/uPJN7EeM4pKh5f94pwj0le/%ED%99%88%ED%8E%98%EC%9D%B4%EC%A7%80-%EB%A7%8C%EB%93%A4%EA%B8%B0.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  